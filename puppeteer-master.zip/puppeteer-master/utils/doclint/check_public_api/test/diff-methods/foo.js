class Foo {
  start() {
  }

  stop() {
  }

  get zzz() {
  }

  $() {
  }

  money$$money() {
  }
}
