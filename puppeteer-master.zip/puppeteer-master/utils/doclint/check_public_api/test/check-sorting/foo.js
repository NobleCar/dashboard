class Foo {
  constructor() {
    this.ddd = 10;
  }

  aaa() {}

  bbb() {}

  ccc() {}
}

Foo.Events = {
  a: 'a',
  b: 'b',
  c: 'c'
}
