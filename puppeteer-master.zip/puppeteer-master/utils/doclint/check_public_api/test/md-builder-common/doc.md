### class: Foo

This is a class.

#### event: 'frame'
- <[Frame]> 

This event is dispatched.

#### foo.$(selector)
- `selector` <[string]> A selector to query page for
- returns: <[Promise]<[ElementHandle]>>

The method runs document.querySelector.

#### foo.url
- <[string]>

Contains the URL of the request.
